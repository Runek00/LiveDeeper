package com.example.live_deeper;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LiveDeeperApplication {

	public static void main(String[] args) {
		SpringApplication.run(LiveDeeperApplication.class, args);
	}

}
