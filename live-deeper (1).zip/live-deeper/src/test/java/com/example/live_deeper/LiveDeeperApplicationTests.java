package com.example.live_deeper;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LiveDeeperApplicationTests {

	@Test
	void contextLoads() {
	}

}
